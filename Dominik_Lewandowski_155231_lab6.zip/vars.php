<?php
    $color = 'czerwony';
    $item = 'samochod';
?>